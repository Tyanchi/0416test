$(function () {
    /*初始方向变量*/
    var direction = {up: 1, right: 2, down: 3, left: 4};
    /*初始化page的横纵坐标*/
    var now = {col: 1, row: 1};
    var last = {col: 1, row: 1};

    //标识符 动画没有进行
    var isMoving = false;


    /*定义滑动事件*/
    /*向上滑动*/
    $(document).swipeUp(function () {
        //判断动画是否进行
        if(isMoving){
            return;
        }

        //将马上出场的页面的坐标赋值给出厂后上一个页面  取值，赋值
        last.col = now.col;
        last.row = now.row;

        if(last.col<5){
            now.col = last.col + 1;
            now.row = 1;
            movePage(direction.up);
        }

    });

    /*向下滑动*/
    $(document).swipeDown(function () {

        if(isMoving){
            return;
        }

        last.col = now.col;
        last.row = now.row;

        if(last.col>1){
            now.col = last.col - 1;
            now.row = 1;
            movePage(direction.down)
        }

    });








    /*定义move函数*/
    function movePage(dir) {
        //初始化两个动画类
        var inClass = '';
        var outClass = '';

        /*初始化两个页面*/
        var nowPage = '.page-' +now.col+ '-' +now.row;
        var lastPage = '.page-' +last.col+ '-' +last.row;

        /*匹配方向*/
        switch (dir){
            case direction.up:
                outClass = 'pt-page-moveToTop';
                inClass = 'pt-page-moveFromBottom';
                break;
            case direction.down:
                outClass = 'pt-page-moveToBottom';
                inClass = 'pt-page-moveFromTop';
                break;
        }

        /*为两个页面添加动画类*/
        $(lastPage).addClass(outClass);
        $(nowPage).removeClass('hide');
        $(nowPage).addClass(inClass);

        isMoving = true;

        /*动画执行完后的操作*/
        setTimeout(function () {
            $(lastPage).removeClass(outClass);
            $(lastPage).addClass('hide');
            $(lastPage).removeClass('page_current');
            $(lastPage).find('ul').addClass('hide');
            $(lastPage).find('li').addClass('hide');
            $(lastPage).find('div').addClass('hide');

            $(nowPage).removeClass(inClass);
            $(nowPage).addClass('page_current');
            $(nowPage).find('ul').removeClass('hide');
            $(nowPage).find('li').removeClass('hide');
            $(nowPage).find('div').removeClass('hide');

            //重置标识符
            isMoving = false;

        },600)
    }
});